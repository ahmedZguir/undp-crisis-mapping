"""Build extra4 evidence packets from DisasterVL API outputs."""

from __future__ import annotations

import re
import json
from pathlib import Path
from typing import Any


NEGATIVE_PATTERNS = (
    "no visible",
    "no evidence",
    "not visible",
    "not apparent",
    "not observed",
    "cannot confirm",
    "cannot be confirmed",
    "unclear",
    "unknown",
)

UNCERTAINTY_PATTERNS = (
    "uncertain",
    "unclear",
    "unknown",
    "cannot determine",
    "cannot confirm",
    "difficult to determine",
    "not enough evidence",
    "insufficient evidence",
)


def build_api_v2_evidence_packet(
    *,
    image_path: str = "",
    image_id: str = "",
    caption_response: dict[str, Any] | str | None = None,
    incident_reasoning_response: dict[str, Any] | str | None = None,
    reasoning_vqa_responses: list[dict[str, Any] | str] | None = None,
    source: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Normalize DisasterVL API answers into the extra4 evidence-packet shape.

    The v2 path starts from API output rather than from the older full DisasterVL
    JSON annotation. We still expose familiar keys such as ``caption`` and
    ``incident_assessment`` so candidate rules and contradiction checks can be
    reused without special cases.
    """
    source = source or {}
    image_path = image_path or source.get("image_path", "")
    image_id = image_id or source.get("image_id", "") or Path(image_path).stem

    api_outputs = source.get("disastervl_api_outputs") or {}
    caption_response = caption_response if caption_response is not None else api_outputs.get("caption")
    incident_reasoning_response = (
        incident_reasoning_response
        if incident_reasoning_response is not None
        else api_outputs.get("incident_reasoning")
    )
    reasoning_vqa_responses = (
        reasoning_vqa_responses
        if reasoning_vqa_responses is not None
        else api_outputs.get("reasoning_vqa", [])
    )

    caption_answer = _answer_text(caption_response)
    incident_answer = _answer_text(incident_reasoning_response)
    reasoning_answers = [_answer_text(r) for r in reasoning_vqa_responses or []]
    all_text = "\n".join(
        t for t in [caption_answer, incident_answer, *reasoning_answers] if t
    )

    return {
        "source": "disastervl_api_v2",
        "image_id": image_id,
        "image_path": image_path,
        "caption": caption_answer,
        "incident_assessment": {
            "likely_type": _infer_incident_type(incident_answer),
            "canonical_type": "",
            "confidence": _infer_confidence(incident_answer),
            "evidence": incident_answer,
        },
        "location_assessment": {},
        "relationships": [],
        "visible_text": [],
        "uncertainties": _extract_matching_sentences(all_text, UNCERTAINTY_PATTERNS),
        "collection_location": "",
        "vqa_evidence": [t for t in [caption_answer, incident_answer, *reasoning_answers] if t],
        "vqa_absence_checks": _extract_matching_sentences(all_text, NEGATIVE_PATTERNS),
        "api_outputs": {
            "caption": _compact_response(caption_response),
            "incident_reasoning": _compact_response(incident_reasoning_response),
            "reasoning_vqa": [_compact_response(r) for r in reasoning_vqa_responses or []],
        },
    }


def load_api_v2_source(source: dict[str, Any]) -> dict[str, Any]:
    """Build an evidence packet from a saved v2 source JSON object."""
    return build_api_v2_evidence_packet(source=source)


def text_blob(packet: dict[str, Any]) -> str:
    """Concatenate evidence fields into a lowercased blob for candidate rules."""
    parts = [
        packet.get("caption") or "",
        json.dumps(packet.get("incident_assessment") or {}, ensure_ascii=False),
        json.dumps(packet.get("relationships") or [], ensure_ascii=False),
        json.dumps(packet.get("uncertainties") or [], ensure_ascii=False),
        json.dumps(packet.get("vqa_evidence") or [], ensure_ascii=False),
        json.dumps(packet.get("vqa_absence_checks") or [], ensure_ascii=False),
    ]
    return " ".join(parts).lower()


def _answer_text(response: dict[str, Any] | str | None) -> str:
    if response is None:
        return ""
    if isinstance(response, str):
        return response.strip()
    if isinstance(response, dict):
        return str(response.get("answer") or response.get("text") or "").strip()
    return str(response).strip()


def _compact_response(response: dict[str, Any] | str | None) -> dict[str, Any] | str:
    if not isinstance(response, dict):
        return _answer_text(response)
    keep = {
        "answer",
        "task",
        "requested_mode",
        "effective_mode",
        "route_reason",
        "model_loaded",
    }
    return {k: response.get(k) for k in keep if k in response}


def _extract_matching_sentences(text: str, patterns: tuple[str, ...]) -> list[str]:
    seen = set()
    items: list[str] = []
    for part in re.split(r"(?<=[.!?])\s+|\n+|;\s+", text or ""):
        clean = " ".join(part.strip().split())
        if not clean:
            continue
        low = clean.lower()
        if any(p in low for p in patterns) and clean not in seen:
            seen.add(clean)
            items.append(clean)
    return items[:20]


def _infer_confidence(text: str) -> str:
    low = (text or "").lower()
    if "high confidence" in low or "confidence: high" in low:
        return "high"
    if "medium confidence" in low or "moderate confidence" in low or "confidence: medium" in low:
        return "medium"
    if "low confidence" in low or "confidence: low" in low:
        return "low"
    if any(p in low for p in UNCERTAINTY_PATTERNS):
        return "low"
    return "unknown"


def _infer_incident_type(text: str) -> str:
    low = (text or "").lower()
    for label, keywords in (
        ("fire", ("fire", "flame", "smoke", "burn")),
        ("flood", ("flood", "submerged", "standing water")),
        ("earthquake", ("earthquake", "seismic", "collapsed building", "rubble")),
        ("storm", ("storm", "hurricane", "tornado", "wind damage")),
        ("landslide", ("landslide", "mudslide", "slope failure")),
    ):
        if any(k in low for k in keywords):
            return label
    return "unknown"
