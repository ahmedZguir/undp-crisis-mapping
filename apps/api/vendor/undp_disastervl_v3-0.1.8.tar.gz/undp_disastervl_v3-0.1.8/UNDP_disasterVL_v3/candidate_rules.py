"""Rule-based candidate label pre-extraction from evidence packets.

Candidates are passed to the LLM as hints; the LLM may accept, reject,
or lower confidence for any candidate based on the full evidence.
"""

from __future__ import annotations

from .evidence_builder import text_blob

# ---------------------------------------------------------------------------
# Severity keyword rules  (checked in priority order: destroyed -> none -> moderate)
# ---------------------------------------------------------------------------

SEVERITY_RULES: list[tuple[str, list[str]]] = [
    ("destroyed", [
        "completely destroyed", "leveled", "flattened", "total collapse",
        "reduced to rubble", "washed away", "burned out", "fully collapsed",
    ]),
    ("none", [
        "no visible damage", "appears intact", "no damage visible",
    ]),
    ("moderate", [
        "structural collapse", "extensive structural damage", "large sections",
        "collapsed", "exposed interiors", "rubble piled", "missing exterior walls",
        "heavy damage", "severely damaged", "major structural",
        "visible damage", "damaged roof", "cracked walls", "partial damage",
        "broken windows", "debris", "damaged facade",
        "minor damage", "small cracks", "light damage", "slight damage",
        "limited debris",
    ]),
]

# ---------------------------------------------------------------------------
# Humanitarian needs keyword rules
# ---------------------------------------------------------------------------

NEED_RULES: dict[str, list[str]] = {
    "debris_clearance": ["rubble", "debris", "collapsed", "wreckage"],
    "structural_safety_inspection": [
        "structural damage", "collapsed walls", "exposed concrete",
        "cracks", "exposed interiors",
    ],
    "road_access_assessment": [
        "road", "street", "blocked", "barrier", "debris on road",
    ],
    "road_access_restoration": [
        "blocked road", "impassable", "washed out road", "collapsed bridge",
    ],
    "fire_response": ["fire", "smoke", "flames", "burning"],
    "flood_water_pumping": [
        "floodwater", "standing water", "submerged", "water damage",
    ],
    "medical_support": ["injured", "wounded", "ambulance", "medical personnel"],
    "search_and_rescue": ["trapped", "rescue", "people under rubble"],
    "temporary_housing_assessment": [
        "residential building", "apartment", "homes", "houses",
    ],
    "power_restoration": ["power line", "electric pole", "utility pole", "outage"],
    "food_water_sanitation": ["water supply", "contaminated water", "sanitation"],
}

# ---------------------------------------------------------------------------
# Affected asset keyword rules
# ---------------------------------------------------------------------------

ASSET_RULES: dict[str, list[str]] = {
    "residential_building": [
        "residential building", "apartment", "homes", "houses", "multi-story",
    ],
    "commercial_building": [
        "shop", "store", "commercial building", "market",
    ],
    "school": ["school", "classroom", "students"],
    "hospital": ["hospital", "clinic", "medical center"],
    "road": ["road", "street", "highway"],
    "bridge": ["bridge", "overpass"],
    "sidewalk": ["sidewalk", "pavement"],
    "traffic_signal": ["traffic light", "traffic signal"],
    "power_line": ["power line", "electric pole", "utility pole"],
    "water_network": ["water pipe", "water treatment", "water network"],
    "telecom_infrastructure": ["cell tower", "telecom", "antenna"],
    "vehicle": ["car", "truck", "bus", "vehicle"],
    "excavator": ["excavator", "heavy machinery", "bulldozer"],
    "emergency_vehicle": ["ambulance", "fire truck", "police car"],
    "agricultural_land": ["agricultural", "farmland", "crops", "fields"],
    "forest": ["forest", "trees", "vegetation"],
    "river": ["river", "stream", "canal"],
}


def extract_candidates(packet: dict) -> dict[str, list[str]]:
    """Return rule-based candidate labels for all four tasks."""
    txt = text_blob(packet)

    # Severity: pick the highest-matching level
    severity_candidate: list[str] = []
    for label, keywords in SEVERITY_RULES:
        if any(kw in txt for kw in keywords):
            severity_candidate = [label]
            break

    needs: list[str] = [
        label for label, kws in NEED_RULES.items() if any(kw in txt for kw in kws)
    ]
    assets: list[str] = [
        label for label, kws in ASSET_RULES.items() if any(kw in txt for kw in kws)
    ]

    return {
        "candidate_damage_severity": severity_candidate,
        "candidate_humanitarian_needs": sorted(set(needs)),
        "candidate_affected_assets": sorted(set(assets)),
    }
