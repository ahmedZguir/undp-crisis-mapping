"""Library API for DisasterVL extra4 annotations with in-process vLLM.

This module does not start an HTTP server. Import ``DisasterVLVLLM`` from your
own Python code, instantiate it once, and reuse it for many images.
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
import base64
from io import BytesIO
import os
from pathlib import Path
from typing import Any

from PIL import Image, ImageOps
import requests

from .candidate_rules import extract_candidates
from .contradiction_checker import check as check_contradictions
from .evidence_builder import build_api_v2_evidence_packet
from .extra4_prompts import build_api_v2_annotation_messages, build_repair_messages
from .json_utils import extract_json
from .schema_validator import validate as validate_schema
from .tasks import build_task_prompt


DEFAULT_ADAPTER_PATH = (
    "/home/local/QCRI/adiba/CR1M_VLM/experiments/"
    "Q35VL_9B_MCQ_final_XLData_2/CR1M_data/checkpoints/best_checkpoint"
)
DEFAULT_BASE_MODEL = "Qwen/Qwen3.5-9B"
PROMPT_VERSION = "extra4_vllm_library_v3_damage4"
SCHEMA_VERSION = "extra4_v1.1"

DISASTER_SYSTEM_PROMPT = (
    "You are a helpful visual question answering assistant specialized in disaster scene analysis. "
    "Follow the requested response format and use only visible evidence for image-grounded answers."
)
BASE_SYSTEM_PROMPT = "You are a helpful assistant."

DEFAULT_INCIDENT_QUERY = (
    "Give the likely incident type, visible evidence, uncertainties, and explicit "
    "absence checks for fire, flooding, injured people, trapped people, evacuation, "
    "blocked road, and damaged critical infrastructure. Be concise and evidence-grounded."
)

TASK_TEMPERATURES = {
    "caption": 0.45,
    "vqa": 0.25,
    "reasoning_vqa": 0.25,
    "incident_classification": 0.10,
    "incident_reasoning": 0.10,
}

TASK_CAPTION = "caption"
TASK_REASONING_VQA = "reasoning_vqa"
TASK_INCIDENT_CLASSIFICATION = "incident_classification"
TASK_INCIDENT_REASONING = "incident_reasoning"
TASK_VQA = "vqa"


@dataclass(frozen=True)
class DisasterVLVLLMConfig:
    base_model: str = DEFAULT_BASE_MODEL
    adapter_path: str = DEFAULT_ADAPTER_PATH
    adapter_name: str = "disastervl"
    adapter_id: int = 1
    tensor_parallel_size: int = 1
    dtype: str = "bfloat16"
    max_model_len: int | None = None
    max_num_seqs: int = 8
    max_lora_rank: int = 32
    gpu_memory_utilization: float = 0.90
    trust_remote_code: bool = True
    target_image_size: int = 768
    default_max_tokens: int = 256
    extra4_max_tokens: int = 1024
    temperature: float = 0.2
    seed: int = 0
    limit_images_per_prompt: int = 1
    use_tqdm: bool = False
    use_guided_json: bool = True

    @classmethod
    def from_env(cls) -> "DisasterVLVLLMConfig":
        max_model_len = os.getenv("UNDP_V3_MAX_MODEL_LEN")
        return cls(
            base_model=os.getenv("UNDP_V3_BASE_MODEL", DEFAULT_BASE_MODEL),
            adapter_path=os.getenv("UNDP_V3_ADAPTER_PATH", DEFAULT_ADAPTER_PATH),
            adapter_name=os.getenv("UNDP_V3_ADAPTER_NAME", "disastervl"),
            adapter_id=int(os.getenv("UNDP_V3_ADAPTER_ID", "1")),
            tensor_parallel_size=int(os.getenv("UNDP_V3_TENSOR_PARALLEL_SIZE", "1")),
            dtype=os.getenv("UNDP_V3_DTYPE", "bfloat16"),
            max_model_len=int(max_model_len) if max_model_len else None,
            max_num_seqs=int(os.getenv("UNDP_V3_MAX_NUM_SEQS", "8")),
            max_lora_rank=int(os.getenv("UNDP_V3_MAX_LORA_RANK", "32")),
            gpu_memory_utilization=float(os.getenv("UNDP_V3_GPU_MEMORY_UTILIZATION", "0.90")),
            target_image_size=int(os.getenv("UNDP_V3_IMAGE_SIZE", "768")),
            default_max_tokens=int(os.getenv("UNDP_V3_DEFAULT_MAX_TOKENS", "256")),
            extra4_max_tokens=int(os.getenv("UNDP_V3_EXTRA4_MAX_TOKENS", "1024")),
            temperature=float(os.getenv("UNDP_V3_TEMPERATURE", "0.2")),
            seed=int(os.getenv("UNDP_V3_SEED", "0")),
            use_tqdm=_env_flag("UNDP_V3_USE_TQDM", False),
            use_guided_json=_env_flag("UNDP_V3_USE_GUIDED_JSON", True),
        )


@dataclass(frozen=True)
class DisasterVLRemoteVLLMConfig:
    api_base: str = "http://127.0.0.1:8000/v1"
    api_key: str = "EMPTY"
    base_model: str = DEFAULT_BASE_MODEL
    disaster_model: str = "disastervl"
    target_image_size: int = 768
    default_max_tokens: int = 256
    extra4_max_tokens: int = 1024
    temperature: float = 0.2
    timeout: int = 900
    use_guided_json: bool = True

    @classmethod
    def from_env(cls) -> "DisasterVLRemoteVLLMConfig":
        return cls(
            api_base=os.getenv("UNDP_V3_REMOTE_API_BASE", "http://127.0.0.1:8000/v1").rstrip("/"),
            api_key=os.getenv("UNDP_V3_REMOTE_API_KEY", "EMPTY"),
            base_model=os.getenv("UNDP_V3_REMOTE_BASE_MODEL", DEFAULT_BASE_MODEL),
            disaster_model=os.getenv("UNDP_V3_REMOTE_DISASTER_MODEL", "disastervl"),
            target_image_size=int(os.getenv("UNDP_V3_IMAGE_SIZE", "768")),
            default_max_tokens=int(os.getenv("UNDP_V3_DEFAULT_MAX_TOKENS", "256")),
            extra4_max_tokens=int(os.getenv("UNDP_V3_EXTRA4_MAX_TOKENS", "1024")),
            temperature=float(os.getenv("UNDP_V3_TEMPERATURE", "0.2")),
            timeout=int(os.getenv("UNDP_V3_REMOTE_TIMEOUT_SECONDS", "900")),
            use_guided_json=_env_flag("UNDP_V3_USE_GUIDED_JSON", True),
        )


class _Extra4Mixin:
    config: Any
    _supports_parallel_inference: bool = False

    def caption(self, image: str | Path | Image.Image, query: str = "") -> str:
        prompt = _task_prompt("caption", query)
        return self._generate_disaster(
            prompt,
            _load_image(image, self.config.target_image_size),
            "caption",
        )

    def incident_reasoning(
        self,
        image: str | Path | Image.Image,
        query: str = DEFAULT_INCIDENT_QUERY,
    ) -> str:
        prompt = _task_prompt("incident_reasoning", query)
        return self._generate_disaster(
            prompt,
            _load_image(image, self.config.target_image_size),
            "incident_reasoning",
        )

    def reasoning_vqa(self, image: str | Path | Image.Image, query: str) -> str:
        prompt = _task_prompt("reasoning_vqa", query)
        return self._generate_disaster(
            prompt,
            _load_image(image, self.config.target_image_size),
            "reasoning_vqa",
        )

    def analyze(
        self,
        image: str | Path | Image.Image,
        *,
        task: str = "all",
        image_id: str = "",
        image_path: str = "",
        caption_query: str = "",
        incident_query: str = DEFAULT_INCIDENT_QUERY,
        reasoning_vqa_queries: list[str] | None = None,
        return_evidence_packet: bool = True,
        return_disastervl_outputs: bool = True,
        return_raw_llm_output: bool = False,
    ) -> dict[str, Any]:
        """Run one selected task or the full pipeline.

        task values:
          caption | incident_reasoning | reasoning_vqa | all
        """
        normalized = _normalize_requested_task(task)
        inferred_path = str(image) if isinstance(image, (str, Path)) else image_path
        image_path = image_path or inferred_path
        image_id = image_id or Path(image_path).stem if image_path else image_id

        if normalized == "caption":
            return {
                "image_id": image_id,
                "image_path": image_path,
                "task": "caption",
                "caption": self.caption(image, caption_query),
                "model_routing": self._task_model_routing("caption"),
            }

        if normalized == "incident_reasoning":
            return {
                "image_id": image_id,
                "image_path": image_path,
                "task": "incident_reasoning",
                "incident_reasoning": self.incident_reasoning(image, incident_query),
                "model_routing": self._task_model_routing("incident_reasoning"),
            }

        if normalized == "reasoning_vqa":
            if not reasoning_vqa_queries:
                raise ValueError(
                    "task='reasoning_vqa' requires at least one reasoning_vqa query. "
                    "Use --reasoning_vqa_query on the CLI."
                )
            outputs = [
                {"query": query, "answer": self.reasoning_vqa(image, query)}
                for query in reasoning_vqa_queries or []
            ]
            return {
                "image_id": image_id,
                "image_path": image_path,
                "task": "reasoning_vqa",
                "reasoning_vqa": outputs,
                "model_routing": self._task_model_routing("reasoning_vqa"),
            }

        return self.analyze_extra4(
            image,
            image_id=image_id,
            image_path=image_path,
            caption_query=caption_query,
            incident_query=incident_query,
            reasoning_vqa_queries=reasoning_vqa_queries,
            return_evidence_packet=return_evidence_packet,
            return_disastervl_outputs=return_disastervl_outputs,
            return_raw_llm_output=return_raw_llm_output,
        )

    def analyze_extra4(
        self,
        image: str | Path | Image.Image,
        *,
        image_id: str = "",
        image_path: str = "",
        caption_query: str = "",
        incident_query: str = DEFAULT_INCIDENT_QUERY,
        reasoning_vqa_queries: list[str] | None = None,
        return_evidence_packet: bool = True,
        return_disastervl_outputs: bool = True,
        return_raw_llm_output: bool = False,
    ) -> dict[str, Any]:
        img = _load_image(image, self.config.target_image_size)
        inferred_path = str(image) if isinstance(image, (str, Path)) else image_path
        image_path = image_path or inferred_path
        image_id = image_id or Path(image_path).stem if image_path else image_id

        if self._supports_parallel_inference:
            with ThreadPoolExecutor(max_workers=2) as executor:
                fut_caption = executor.submit(
                    self._generate_disaster,
                    _task_prompt("caption", caption_query),
                    img,
                    "caption",
                )
                fut_incident = executor.submit(
                    self._generate_disaster,
                    _task_prompt("incident_reasoning", incident_query),
                    img,
                    "incident_reasoning",
                )
                caption_answer = fut_caption.result()
                incident_answer = fut_incident.result()
        else:
            caption_answer = self._generate_disaster(
                _task_prompt("caption", caption_query),
                img,
                "caption",
            )
            incident_answer = self._generate_disaster(
                _task_prompt("incident_reasoning", incident_query),
                img,
                "incident_reasoning",
            )

        reasoning_outputs: list[dict[str, Any]] = []
        for query in reasoning_vqa_queries or []:
            reasoning_outputs.append({
                "answer": self._generate_disaster(
                    _task_prompt("reasoning_vqa", query),
                    img,
                    "reasoning_vqa",
                ),
                "task": "reasoning_vqa",
                "query": query,
            })

        disastervl_outputs = {
            "caption": {"answer": caption_answer, "task": "caption"},
            "incident_reasoning": {
                "answer": incident_answer,
                "task": "incident_reasoning",
            },
            "reasoning_vqa": reasoning_outputs,
        }

        packet = build_api_v2_evidence_packet(
            image_path=image_path,
            image_id=image_id,
            caption_response=disastervl_outputs["caption"],
            incident_reasoning_response=disastervl_outputs["incident_reasoning"],
            reasoning_vqa_responses=reasoning_outputs,
        )
        result = self.annotate_extra4_from_packet(
            packet,
            return_raw_llm_output=return_raw_llm_output,
        )
        result["image_id"] = image_id
        result["image_path"] = image_path
        if return_disastervl_outputs:
            result["disastervl_outputs"] = disastervl_outputs
        if return_evidence_packet:
            result["disastervl_api_evidence_packet"] = packet
        return result

    def annotate_extra4_from_packet(
        self,
        packet: dict[str, Any],
        *,
        return_raw_llm_output: bool = False,
    ) -> dict[str, Any]:
        candidates = extract_candidates(packet)
        messages = build_api_v2_annotation_messages(packet, candidates)
        prompt = _messages_to_single_prompt(messages)

        raw = self._generate_base(
            prompt,
            "extra4_annotation",
            max_tokens=self.config.extra4_max_tokens,
        )
        annotation, validation_errors = _parse_and_validate(raw)
        repaired = False

        if validation_errors:
            repair_prompt = _messages_to_single_prompt(build_repair_messages(validation_errors, raw))
            repair_raw = self._generate_base(
                repair_prompt,
                "extra4_annotation_repair",
                max_tokens=self.config.extra4_max_tokens,
            )
            repaired_annotation = extract_json(repair_raw)
            if repaired_annotation is not None:
                repair_errors = validate_schema(repaired_annotation)
                if len(repair_errors) < len(validation_errors):
                    annotation = repaired_annotation
                    validation_errors = repair_errors
                    repaired = True

        schema_passed = len(validation_errors) == 0
        validation_status = "passed" if schema_passed else (
            "rejected" if not annotation else "flagged"
        )
        contradiction_flags = check_contradictions(annotation, packet) if schema_passed else []
        if contradiction_flags:
            validation_status = "flagged"

        priority = annotation.get("priority_risk") if isinstance(annotation, dict) else {}
        if isinstance(priority, dict):
            priority["human_review_required"] = (
                validation_status != "passed"
                or priority.get("label") in ("critical", "high")
                or bool(contradiction_flags)
            )

        metadata = {
            "source": "undp_disastervl_v3_vllm_library",
            "backend": self._backend_name,
            "adapter_usage": {
                "caption": self._disaster_adapter_label,
                "incident_reasoning": self._disaster_adapter_label,
                "reasoning_vqa": self._disaster_adapter_label,
                "extra4_annotation": self._base_model_label,
            },
            "base_model": self.config.base_model,
            "annotation_version": SCHEMA_VERSION,
            "prompt_version": PROMPT_VERSION,
            "validation_status": validation_status,
            "validation_errors": validation_errors,
            "contradiction_flags": contradiction_flags,
            "repaired": repaired,
            "candidate_labels": candidates,
        }
        adapter_path = getattr(self.config, "adapter_path", "")
        if adapter_path:
            metadata["adapter_path"] = adapter_path
        disaster_model = getattr(self.config, "disaster_model", "")
        if disaster_model:
            metadata["disaster_model"] = disaster_model
        if return_raw_llm_output:
            metadata["raw_llm_output"] = raw

        return {
            "extra_task_annotations": annotation,
            "annotation_metadata": metadata,
        }

    def analyze_extra4_batch(
        self,
        images: list[str | Path | Image.Image],
        *,
        max_workers: int = 4,
        **kwargs: Any,
    ) -> list[dict[str, Any]]:
        """Process multiple images concurrently.

        The vLLM server batches concurrent HTTP requests automatically, giving
        near-linear throughput gains up to max_workers for DisasterVLRemoteVLLM.
        For DisasterVLVLLM (in-process), use max_workers=1 to avoid concurrent
        CUDA contention on the shared LLM instance.
        """
        results: list[dict[str, Any] | None] = [None] * len(images)
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_idx = {
                executor.submit(self.analyze_extra4, img, **kwargs): i
                for i, img in enumerate(images)
            }
            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                results[idx] = future.result()
        return results  # type: ignore[return-value]

    def _generate_disaster(self, prompt: str, image: Image.Image, task_family: str) -> str:
        raise NotImplementedError

    def _generate_base(self, prompt: str, task_family: str, max_tokens: int) -> str:
        raise NotImplementedError

    def _task_model_routing(self, task: str) -> dict[str, Any]:
        return {
            task: self._disaster_adapter_label,
            "uses_disaster_adapter": True,
            "base_model_for_extra4_only": self._base_model_label,
        }


class DisasterVLVLLM(_Extra4Mixin):
    """Reusable in-process vLLM pipeline.

    Instantiate once per process. vLLM owns the GPU memory for the lifetime of
    the object.
    """

    def __init__(self, config: DisasterVLVLLMConfig | None = None):
        self.config = config or DisasterVLVLLMConfig.from_env()
        self._llm = None
        self._lora_request = None
        self._backend_name = "vllm_in_process"
        self._disaster_adapter_label = "disaster_lora"
        self._base_model_label = "base_model_no_lora"

    @property
    def loaded(self) -> bool:
        return self._llm is not None

    def load(self) -> None:
        if self._llm is not None:
            return

        try:
            from vllm import LLM
            from vllm.lora.request import LoRARequest
        except ImportError as exc:
            raise RuntimeError(
                "vLLM is required for UNDP_disasterVL_v3. Install vllm in this environment."
            ) from exc

        kwargs: dict[str, Any] = {
            "model": self.config.base_model,
            "enable_lora": True,
            "max_lora_rank": self.config.max_lora_rank,
            "trust_remote_code": self.config.trust_remote_code,
            "dtype": self.config.dtype,
            "tensor_parallel_size": self.config.tensor_parallel_size,
            "max_num_seqs": self.config.max_num_seqs,
            "gpu_memory_utilization": self.config.gpu_memory_utilization,
            "limit_mm_per_prompt": {"image": self.config.limit_images_per_prompt},
            "seed": self.config.seed,
        }
        if self.config.max_model_len:
            kwargs["max_model_len"] = self.config.max_model_len

        self._llm = LLM(**kwargs)
        self._lora_request = LoRARequest(
            self.config.adapter_name,
            self.config.adapter_id,
            self.config.adapter_path,
        )

    def _generate_disaster(self, prompt: str, image: Image.Image, task_family: str) -> str:
        prompt = _format_task_prompt(prompt, task_family)
        return self._chat(
            messages=[
                {"role": "system", "content": DISASTER_SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": [
                        {"type": "image"},
                        {"type": "text", "text": prompt},
                    ],
                },
            ],
            image=image,
            task_family=task_family,
            max_tokens=self.config.default_max_tokens,
            use_lora=True,
        )

    def _generate_base(self, prompt: str, task_family: str, max_tokens: int) -> str:
        return self._chat(
            messages=[
                {"role": "system", "content": BASE_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            image=None,
            task_family=task_family,
            max_tokens=max_tokens,
            use_lora=False,
        )

    def _chat(
        self,
        *,
        messages: list[dict[str, Any]],
        image: Image.Image | None,
        task_family: str,
        max_tokens: int,
        use_lora: bool,
    ) -> str:
        self.load()
        from vllm import SamplingParams

        sampling_kwargs: dict[str, Any] = {
            "temperature": _temperature(self.config.temperature, task_family),
            "max_tokens": max_tokens,
        }
        if task_family.startswith("extra4_annotation") and self.config.use_guided_json:
            try:
                from vllm.sampling_params import GuidedDecodingParams
                sampling_kwargs["guided_decoding"] = GuidedDecodingParams(json_object=True)
            except (ImportError, TypeError):
                pass
        params = SamplingParams(**sampling_kwargs)
        kwargs: dict[str, Any] = {
            "sampling_params": params,
            "use_tqdm": self.config.use_tqdm,
            "chat_template_kwargs": {"enable_thinking": False},
        }
        if use_lora:
            kwargs["lora_request"] = self._lora_request

        try:
            outputs = self._llm.chat(messages, **kwargs)
        except Exception:
            # Compatibility fallback for older vLLM versions that require
            # generate() with explicit multi_modal_data.
            fallback_kwargs = dict(kwargs)
            fallback_kwargs.pop("chat_template_kwargs", None)
            tokenizer = self._llm.get_tokenizer()
            try:
                prompt = tokenizer.apply_chat_template(
                    messages,
                    tokenize=False,
                    add_generation_prompt=True,
                    enable_thinking=False,
                )
            except TypeError:
                prompt = tokenizer.apply_chat_template(
                    messages,
                    tokenize=False,
                    add_generation_prompt=True,
                )
            request: dict[str, Any] = {"prompt": prompt}
            if image is not None:
                request["multi_modal_data"] = {"image": image}
            outputs = self._llm.generate(request, **fallback_kwargs)

        return outputs[0].outputs[0].text.strip()


class DisasterVLRemoteVLLM(_Extra4Mixin):
    """Library client for an external vLLM OpenAI-compatible server."""

    def __init__(self, config: DisasterVLRemoteVLLMConfig | None = None):
        self.config = config or DisasterVLRemoteVLLMConfig.from_env()
        self._loaded = False
        self._supports_parallel_inference = True
        self._backend_name = "vllm_remote_openai"
        self._disaster_adapter_label = f"remote_model:{self.config.disaster_model}"
        self._base_model_label = f"remote_model:{self.config.base_model}"

    @property
    def loaded(self) -> bool:
        return self._loaded

    def load(self) -> None:
        response = requests.get(
            f"{self.config.api_base}/models",
            headers=self._headers(),
            timeout=self.config.timeout,
        )
        try:
            response.raise_for_status()
        except requests.HTTPError as exc:
            raise RuntimeError(
                f"Could not reach vLLM models endpoint at {self.config.api_base}/models: "
                f"{response.text[:1000]}"
            ) from exc
        self._validate_remote_models(response.json())
        self._loaded = True

    def _generate_disaster(self, prompt: str, image: Image.Image, task_family: str) -> str:
        prompt = _format_task_prompt(prompt, task_family)
        return self._chat_completion(
            model=self.config.disaster_model,
            messages=[
                {"role": "system", "content": DISASTER_SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {"url": _image_to_data_url(image)},
                        },
                        {"type": "text", "text": prompt},
                    ],
                },
            ],
            task_family=task_family,
            max_tokens=self.config.default_max_tokens,
        )

    def _generate_base(self, prompt: str, task_family: str, max_tokens: int) -> str:
        return self._chat_completion(
            model=self.config.base_model,
            messages=[
                {"role": "system", "content": BASE_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            task_family=task_family,
            max_tokens=max_tokens,
        )

    def _chat_completion(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        task_family: str,
        max_tokens: int,
    ) -> str:
        if not self._loaded:
            self.load()
        payload = {
            "model": model,
            "messages": messages,
            "temperature": _temperature(self.config.temperature, task_family),
            "max_tokens": max_tokens,
            "chat_template_kwargs": {"enable_thinking": False},
        }
        if task_family.startswith("extra4_annotation") and self.config.use_guided_json:
            payload["response_format"] = {"type": "json_object"}
        response = requests.post(
            f"{self.config.api_base}/chat/completions",
            headers=self._headers(),
            json=payload,
            timeout=self.config.timeout,
        )
        try:
            response.raise_for_status()
        except requests.HTTPError as exc:
            raise RuntimeError(
                f"vLLM request failed for model='{model}' and task='{task_family}'. "
                f"Make sure the server was launched with "
                f"--lora-modules {self.config.disaster_model}=<adapter_path> "
                f"and that --base_model matches the served base model. "
                f"Response: {response.text[:1000]}"
            ) from exc
        self._loaded = True
        data = response.json()
        try:
            return str(data["choices"][0]["message"]["content"]).strip()
        except (KeyError, IndexError, TypeError) as exc:
            raise RuntimeError(f"Unexpected vLLM response shape: {data}") from exc

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
        }

    def _validate_remote_models(self, data: dict[str, Any]) -> None:
        models = data.get("data", [])
        model_ids = {
            str(item.get("id"))
            for item in models
            if isinstance(item, dict) and item.get("id")
        }
        missing = [
            model
            for model in (self.config.disaster_model, self.config.base_model)
            if model not in model_ids
        ]
        if missing:
            available = ", ".join(sorted(model_ids)) or "<none>"
            raise RuntimeError(
                "The vLLM server is not serving the model names required by this client. "
                f"Missing: {', '.join(missing)}. Available: {available}. "
                f"Launch with base model '{self.config.base_model}' and "
                f"--lora-modules {self.config.disaster_model}=<adapter_path>."
            )


def _task_prompt(task: str, query: str = "") -> str:
    _, prompt = build_task_prompt(task, query)
    return prompt


def _format_task_prompt(message: str, task_family: str) -> str:
    clean = (message or "").strip()

    if task_family == TASK_INCIDENT_REASONING:
        return (
            "Identify the most likely disaster or emergency incident type in the image. "
            "Use only visible evidence.\n\n"
            f"User question:\n{clean}\n\n"
            "Required response format:\n"
            "Final answer: incident_type: <label>\n"
            "Scene description:\n"
            "- <visible objects, setting, and conditions - what you observe directly>\n"
            "Evidence:\n"
            "- <why the scene description supports the incident label - do not repeat scene sentences>\n"
            "Uncertainty:\n"
            "- <what is unclear or not visible>\n"
            "Conclusion: <one concise conclusion>\n\n"
            "Do not answer with only the label. "
            "Scene description and Evidence must not repeat the same sentences."
        )

    if task_family == TASK_REASONING_VQA:
        return (
            "Answer the image question with grounded reasoning based only on visible evidence.\n\n"
            f"Question:\n{clean}\n\n"
            "Required response format:\n"
            "Final answer: <answer>\n"
            "Evidence:\n"
            "- <specific visible elements that support the answer>\n"
            "Uncertainty:\n"
            "- <missing or unclear visual evidence>\n"
            "Conclusion: <one synthesis sentence - must not repeat the Evidence bullets verbatim>"
        )

    if task_family == TASK_INCIDENT_CLASSIFICATION:
        return (
            "Classify the disaster or emergency incident shown in the image. "
            "Return the incident label followed by a confidence tier in parentheses: High, Medium, or Low. "
            "Example: flood (High). No other text.\n\n"
            f"Question: {clean}"
        )

    if task_family == TASK_CAPTION:
        return (
            "Describe the disaster scene shown in the image. Cover these aspects when visible:\n"
            "1. Scene overview: setting, geography, and scale of the event\n"
            "2. Visible damage: structural, environmental, or infrastructure damage\n"
            "3. Human activity: responders, affected people, or bystanders\n"
            "4. Hazards: immediate threats or secondary risks\n\n"
            "Use plain prose. Include only what is visible. Do not invent details.\n\n"
            f"User request: {clean}"
        )

    if task_family == TASK_VQA:
        return (
            "Answer the image question directly using only visible information in the image.\n\n"
            f"Question: {clean}"
        )

    return clean


def _load_image(image: str | Path | Image.Image, max_side: int) -> Image.Image:
    if isinstance(image, Image.Image):
        loaded = image
    else:
        loaded = Image.open(image)
        loaded.load()
    return _resize_image(loaded, max_side)


def _resize_image(image: Image.Image, max_side: int) -> Image.Image:
    image = ImageOps.exif_transpose(image).convert("RGB")
    if max(image.width, image.height) <= max_side:
        return image
    scale = max_side / float(max(image.width, image.height))
    new_size = (
        max(1, int(round(image.width * scale))),
        max(1, int(round(image.height * scale))),
    )
    return image.resize(new_size, Image.Resampling.LANCZOS)


def _image_to_data_url(image: Image.Image) -> str:
    buf = BytesIO()
    image.save(buf, format="JPEG", quality=95)
    encoded = base64.b64encode(buf.getvalue()).decode("ascii")
    return f"data:image/jpeg;base64,{encoded}"


def _messages_to_single_prompt(messages: list[dict[str, str]]) -> str:
    parts: list[str] = []
    for message in messages:
        role = str(message.get("role") or "user").upper()
        content = str(message.get("content") or "").strip()
        if content:
            parts.append(f"{role}:\n{content}")
    return "\n\n".join(parts)


def _parse_and_validate(raw: str) -> tuple[dict[str, Any], list[str]]:
    annotation = extract_json(raw)
    if annotation is None:
        return {}, ["JSON parse failed on initial output"]
    return annotation, validate_schema(annotation)


def _normalize_requested_task(task: str) -> str:
    normalized = (task or "all").strip().lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "full": "all",
        "extra4": "all",
        "extra_annotation": "all",
        "extra_annotations": "all",
        "incident": "incident_reasoning",
        "incident_reason": "incident_reasoning",
        "vqa": "reasoning_vqa",
    }
    normalized = aliases.get(normalized, normalized)
    allowed = {"caption", "incident_reasoning", "reasoning_vqa", "all"}
    if normalized not in allowed:
        raise ValueError(f"Unsupported task '{task}'. Use one of: {', '.join(sorted(allowed))}")
    return normalized


def _temperature(base_temperature: float, task_family: str) -> float:
    if base_temperature <= 0:
        return 0.0
    return TASK_TEMPERATURES.get(task_family, base_temperature)


def _env_flag(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}
