"""Rule-based contradiction checks to prevent unsafe or inconsistent labels."""

from __future__ import annotations

import json


def _stringify(value) -> str:
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else str(value)


def _text_items(value) -> list[str]:
    if not value:
        return []
    if isinstance(value, list):
        return [_stringify(v) for v in value if v]
    return [_stringify(value)]


def check(annotation: dict, packet: dict) -> list[str]:
    """Return a list of contradiction flags (empty = no flags)."""
    flags: list[str] = []

    absence_text = " ".join(
        _text_items(annotation.get("absence_checks"))
        + _text_items(packet.get("vqa_absence_checks"))
    ).lower()

    needs_labels = {n.get("label", "") for n in (annotation.get("humanitarian_needs") or [])}
    severity = (annotation.get("damage_severity") or {}).get("label", "unknown")
    priority = (annotation.get("priority_risk") or {}).get("label", "unknown")
    priority_not_critical = (
        annotation.get("priority_risk") or {}
    ).get("not_critical_reason", "").lower()
    evidence_text = " ".join(
        _text_items((annotation.get("damage_severity") or {}).get("evidence"))
    ).lower()

    # High-risk need checks
    if "medical_support" in needs_labels:
        if not _has_any(absence_text, ["injur", "wound", "ambulance", "medical"]) and \
           _has_any(absence_text, ["no injur", "no medical", "no ambulance", "no wounded"]):
            flags.append(
                "medical_support assigned but absence checks mention no injured people or medical activity"
            )

    if "search_and_rescue" in needs_labels:
        if _has_any(absence_text, ["no trapped", "no rescue", "no people under"]):
            flags.append(
                "search_and_rescue assigned but absence checks mention no trapped people or rescue activity"
            )

    if "fire_response" in needs_labels:
        if _has_any(absence_text, ["no fire", "no smoke", "no flames"]):
            flags.append(
                "fire_response assigned but absence checks mention no fire or smoke"
            )

    if "flood_water_pumping" in needs_labels:
        if _has_any(absence_text, ["no flood", "no water", "no standing water"]):
            flags.append(
                "flood_water_pumping assigned but absence checks mention no flooding"
            )

    if "evacuation" in needs_labels:
        caption = (packet.get("caption") or "").lower()
        if not _has_any(
            caption + " " + evidence_text,
            ["evacuati", "displacement", "unsafe housing", "people leaving", "shelter"],
        ):
            flags.append(
                "evacuation assigned without visible evacuation or displacement evidence"
            )

    # Severity checks
    if severity == "destroyed" and not _has_any(
        evidence_text,
        ["total collapse", "leveled", "flattened", "washed away", "burned out",
         "fully collapsed", "completely destroyed"],
    ):
        flags.append(
            "severity=destroyed but evidence lacks total-loss indicators"
        )

    if severity == "none":
        ia_confidence = (packet.get("incident_assessment") or {}).get("confidence", "")
        if ia_confidence == "high":
            flags.append(
                "severity=none but incident_assessment.confidence=high"
            )

    # Priority checks
    if priority == "critical" and not _has_any(
        evidence_text + " " + " ".join(
            _text_items((annotation.get("priority_risk") or {}).get("rationale"))
        ).lower(),
        ["trap", "injur", "life", "fire", "flood", "hospital", "school", "critical"],
    ):
        flags.append(
            "priority=critical but no direct life-safety evidence found in rationale"
        )

    if priority == "low" and severity == "destroyed":
        flags.append(
            f"priority=low but severity={severity}"
        )

    if priority == "critical" and priority_not_critical and _has_any(
        priority_not_critical,
        ["no visible", "no trapped", "no life-safety"],
    ):
        flags.append(
            "priority=critical but not_critical_reason suggests no life-safety evidence"
        )

    return flags


def _has_any(text: str, keywords: list[str]) -> bool:
    return any(kw in text for kw in keywords)
