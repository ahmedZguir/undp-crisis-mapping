"""Standalone task prompt handling for the UNDP DisasterVL API."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TaskSpec:
    name: str
    prompt: str
    requires_image: bool = True


TASKS: dict[str, TaskSpec] = {
    "caption": TaskSpec("caption", "Describe this image in detail."),
    "vqa": TaskSpec("vqa", ""),
    "reasoning_vqa": TaskSpec(
        "reasoning_vqa",
        "Answer the question with grounded reasoning based only on visible evidence.",
    ),
    "incident_classification": TaskSpec(
        "incident_classification",
        "What type of incident is shown in this image?",
    ),
    "incident_reasoning": TaskSpec(
        "incident_reasoning",
        "What type of incident is shown in this image? Start with `Final answer: "
        "incident_type: <label>`, then justify it using grounded visual evidence.",
    ),
    "relationships": TaskSpec(
        "relationships",
        "Explain the important spatial relationships visible in the image and why they matter.",
    ),
    "uncertainty": TaskSpec(
        "uncertainty",
        "What cannot be determined from this image, and why?",
    ),
    "location": TaskSpec(
        "location",
        "Can the location be identified from the image? Explain your reasoning.",
    ),
    "damage_severity": TaskSpec(
        "damage_severity",
        "Assess the visible disaster damage severity in this image. Answer with one "
        "label from: none, moderate, destroyed, unknown. Then justify "
        "using visible evidence.",
    ),
    "affected_assets": TaskSpec(
        "affected_assets",
        "Identify disaster-relevant visible assets and their condition. For each asset, "
        "provide asset label, status, confidence, and evidence.",
    ),
    "humanitarian_needs": TaskSpec(
        "humanitarian_needs",
        "Based only on visible evidence, identify likely humanitarian or response needs. "
        "Include confidence and evidence. Do not infer high-risk needs unless directly supported.",
    ),
    "priority_risk": TaskSpec(
        "priority_risk",
        "Assign an operational priority risk level for this image: low, medium, high, "
        "critical, or unknown. Provide rationale, recommended actions, and whether "
        "human review is required.",
    ),
}


def normalize_task(task: str | None) -> str:
    normalized = (task or "vqa").strip().lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "qa": "vqa",
        "question_answering": "vqa",
        "reasoning": "reasoning_vqa",
        "incident": "incident_classification",
        "incident_type": "incident_classification",
        "severity": "damage_severity",
        "assets": "affected_assets",
        "needs": "humanitarian_needs",
        "risk": "priority_risk",
        "priority": "priority_risk",
        "spatial_relationships": "relationships",
    }
    normalized = aliases.get(normalized, normalized)
    if normalized not in TASKS:
        raise ValueError(
            f"Unsupported task '{task}'. Supported tasks: {', '.join(sorted(TASKS))}"
        )
    return normalized


def build_task_prompt(task: str | None, query: str | None) -> tuple[str, str]:
    normalized = normalize_task(task)
    clean_query = (query or "").strip()
    spec = TASKS[normalized]

    if normalized == "vqa":
        if not clean_query:
            raise ValueError("query is required when task='vqa'.")
        return normalized, clean_query

    if clean_query:
        return normalized, f"{spec.prompt}\n\nUser query: {clean_query}"
    return normalized, spec.prompt
