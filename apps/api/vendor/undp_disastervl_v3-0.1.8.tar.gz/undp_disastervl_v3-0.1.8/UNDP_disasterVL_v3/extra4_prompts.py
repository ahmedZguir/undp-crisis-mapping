"""Prompt templates for annotation generation and verification."""

from __future__ import annotations

import json

# ---------------------------------------------------------------------------
# Annotation generation
# ---------------------------------------------------------------------------

ANNOTATION_SYSTEM_PROMPT = """\
You are an expert humanitarian disaster annotation assistant operating against the \
following UN-system reference frameworks:

- UNOSAT Comprehensive Damage Assessment (CDA) and the IWG-SEM Building Damage \
  Assessment Guidelines (UN-SPIDER) — the UN-system reference for image-based building \
  damage classification, simplified here to four labels: destroyed | moderate | none, \
  with 'unknown' reserved for non-assessable cases.
- Post-Disaster Needs Assessment Guidelines, Volume A (UNDG / EU / World Bank, 2013; \
  updated March 2015) and the sector-specific PDNA Volume B guides — the recovery-\
  framework anchor for sector taxonomy, Recovery Strategy components, and people-\
  centered prioritization.
- Sendai Framework for Disaster Risk Reduction 2015-2030, Targets C (direct economic \
  loss) and D (damage to critical infrastructure, naming health and education \
  facilities). UNDP reports against these through the Sendai Framework Monitor.
- Disaster Recovery Framework (DRF) Guide (UNDP / EU / GFDRR, March 2020) for short / \
  medium / long-term sequencing of recovery actions.

Your task is to convert an existing DisasterVL annotation into four structured labels:

1. damage_severity     - per-scene building/asset damage classification on a simplified
                         four-label image-based scale: destroyed, moderate, none, or
                         unknown. It rolls up to PDNA Volume A's valuation scheme
                         (destroyed -> total damage; moderate -> partial damage;
                         none -> undamaged; unknown -> not assessable).
2. affected_assets     - physical assets impacted, grouped by PDNA Volume A sector
                         taxonomy (Social / Productive / Infrastructure / Cross-
                         cutting). 'hospital' and 'school' are Sendai Target D critical
                         infrastructure and must be labelled whenever visible.
3. humanitarian_needs  - recovery and response actions partitioned across the four PDNA
                         Recovery Strategy components (reconstruction; resumption of
                         services and access; restoration of governance; risk reduction
                         / Build Back Better) plus an explicit immediate life-safety
                         bucket.
4. priority_risk       - operational priority signal. 'critical' is reserved for
                         life-safety risk OR damage to Sendai Target D critical
                         infrastructure, consistent with PDNA Section 2.2.4.2's people-
                         centered prioritization. Lower levels map to the PDNA / DRF
                         short / medium / long-term sequencing.

You must use only the provided DisasterVL annotation fields (caption, incident_assessment, \
location_assessment, relationships, visible_text, uncertainties, collection_location, and \
VQA evidence and absence checks). Do not invent facts. Do not infer casualties, trapped \
people, medical needs, exact location, disaster cause, ownership (public vs. private), \
macro-economic impact, human-development impact, governance effects, or demographic \
breakdown (including protected attributes such as sex, age, disability) unless explicitly \
supported by the provided evidence. These dimensions are outside the image-annotation \
pipeline's scope and are the responsibility of the in-country PDNA team.

Every positive label MUST cite at least one short piece of evidence copied or closely \
paraphrased from the annotation. Treat VQA absence_check entries as authoritative negative \
evidence and use them to populate not_supported_needs.

Be conservative on high-stakes labels (UNOSAT analyst practice and PDNA evidence-based \
recovery planning both require this). Use 'unknown' or lower confidence when evidence is \
insufficient. The schema is hazard-agnostic and applies equally to natural-hazard imagery \
and complex-emergency imagery (per UNOSAT CDA practice and the PDNA Conflict Sensitivity \
guidance). Preserve the annotation's own uncertainties.

Return valid JSON only. No markdown fences. No commentary."""

ANNOTATION_USER_TEMPLATE = """\
Create extra-task annotations for the following DisasterVL sample, aligned with the
UNOSAT / IWG-SEM image-based damage scale and the PDNA / Sendai recovery framework.

ALLOWED LABELS

damage_severity (simplified four-label image-based scale):
  none | moderate | destroyed | unknown
  - destroyed: total or near-total collapse (>=50% of structure collapsed, or building
               collapsed to ground floor). UNOSAT 'Destroyed'.
  - moderate:  any visible non-destroyed damage, from localized/superficial damage to
               major structural damage where the asset is not totally or near-totally
               collapsed. This absorbs prior minor, moderate, and severe subclasses.
  - none:      no visible damage to the focal asset.
  - unknown:   image evidence insufficient to assess (occluded, distant, low quality).
  PDNA Volume A two-bucket roll-up (for valuation downstream):
    destroyed -> total damage; moderate -> partial damage; none -> undamaged.
  When in doubt between destroyed and moderate, choose moderate.

affected_asset labels grouped by PDNA Volume A sector (Sendai Target D critical
infrastructure marked [*]):
  Social:         residential_building, school[*], hospital[*], religious_building,
                  public_building, sidewalk
  Productive:     commercial_building, market, agricultural_land, fuel_station
  Infrastructure: road, bridge, railway, airport, port, traffic_signal,
                  power_line, power_station, water_network, telecom_infrastructure
  Cross-cutting:  forest, river, coastline
  Response context (not PDNA recovery assets; visible-activity signals):
                  excavator, emergency_vehicle, rescue_worker, vehicle
  Also allowed: unknown
asset_status: visible_nearby | undamaged_or_intact | minor_damage |
  moderate_damage | severely_damaged | destroyed | obstructed |
  partially_impacted | unknown

humanitarian_needs grouped by PDNA Recovery Strategy component:
  Reconstruction:  temporary_housing_assessment, water_infrastructure_repair
  Resumption of services & access:
                   debris_clearance, road_access_assessment, road_access_restoration,
                   power_restoration, communications_restoration, food_water_sanitation,
                   logistics_support, livelihood_support, agricultural_support, shelter
  Risk reduction / BBB: structural_safety_inspection
  Immediate life-safety: search_and_rescue, medical_support, evacuation,
                   fire_response, flood_water_pumping
  Also allowed: unknown

priority_risk: low | medium | high | critical | unknown
  Mapping to PDNA / DRF Guide recovery sequencing:
    critical -> immediate life-safety / Sendai Target D critical infrastructure response
    high     -> short-term recovery (PDNA pp. 32-33)
    medium   -> medium-term recovery
    low      -> long-term recovery
    unknown  -> insufficient evidence to sequence.

RULES
- Use only evidence from the DISASTERVL_EVIDENCE_PACKET. Every positive label needs
  >=1 short evidence string copied/paraphrased from it.
- VQA absence_check entries are binding negative evidence: any contradicting positive
  label goes to not_supported_needs with the absence_check string as 'reason'.
- damage_severity: exactly one label. Apply the four-label definitions above.
  Reserve 'destroyed' for total / near-total loss (UNOSAT >=50% collapse threshold).
- affected_assets: include Sendai Target D critical infrastructure (hospital, school)
  whenever visible, plus other critical assets (bridge, power_station, water_network).
  Use visible_nearby/undamaged_or_intact for adjacent intact assets that matter for
  cross-sector reasoning. Do NOT infer ownership (public vs. private) or protected
  demographic attributes.
- humanitarian_needs: need_type = 'visible' | 'inferred_from_visible_damage' |
  'requires_human_verification'. High-risk needs (search_and_rescue, medical_support,
  evacuation, fire_response, flood_water_pumping) require explicit life-safety / hazard
  evidence; otherwise move to not_supported_needs.
- priority_risk:
    critical = explicit life-safety risk OR damage to Sendai Target D critical
               infrastructure (hospital, school) OR major disruption of a critical
               infrastructure asset (bridge, power_station, water_network, airport,
               port). Anchored in PDNA Section 2.2.4.2 people-centered prioritization.
    high     = destroyed damage but no life-safety signal and no critical-infrastructure
               disruption (prefer over critical here). Maps to PDNA short-term recovery.
    medium   = moderate visible damage / localized disruption. Maps to medium-term recovery.
    low      = no visible damage or only low operational concern. Maps to long-term recovery.
    unknown  = insufficient evidence.
  Populate not_critical_reason whenever label != critical. Sequence recommended_actions
  PDNA-style: life-safety first, then resumption-of-services-and-access, then
  reconstruction, then risk reduction / BBB (PDNA Section 2.2.4 four-component order).
  Set human_review_required=true if any need is 'requires_human_verification' or
  priority is high/critical with unknown location.
- If location_assessment.confidence is low, do NOT assert a specific location.
- Preserve the annotation's own uncertainties.

Return this exact JSON schema (no other text):
{{
  "damage_severity": {{
    "label": "...",
    "confidence": "low|medium|high",
    "evidence": [],
    "uncertainty": []
  }},
  "affected_assets": [
    {{
      "label": "...",
      "status": "...",
      "confidence": "low|medium|high",
      "evidence": "..."
    }}
  ],
  "humanitarian_needs": [
    {{
      "label": "...",
      "confidence": "low|medium|high",
      "evidence": "...",
      "need_type": "visible|inferred_from_visible_damage|requires_human_verification"
    }}
  ],
  "not_supported_needs": [
    {{
      "label": "...",
      "reason": "..."
    }}
  ],
  "priority_risk": {{
    "label": "low|medium|high|critical|unknown",
    "confidence": "low|medium|high",
    "rationale": [],
    "not_critical_reason": "...",
    "recommended_actions": [],
    "human_review_required": true
  }},
  "absence_checks": [],
  "uncertainties": []
}}

DISASTERVL_EVIDENCE_PACKET:
{evidence_packet_json}

CANDIDATE_LABELS:
{candidate_labels_json}"""

# ---------------------------------------------------------------------------
# Repair prompt (used when schema validation fails)
# ---------------------------------------------------------------------------

REPAIR_SYSTEM_PROMPT = """\
You are a JSON repair assistant for disaster annotation data.
Your only task is to fix the provided JSON so it conforms to the required schema \
and uses only allowed label values.
Return valid JSON only. No markdown. No commentary."""

REPAIR_USER_TEMPLATE = """\
The previous annotation output is invalid because:
{validation_errors}

Original (possibly broken) JSON:
{broken_json}

Repair it while preserving the intended labels as much as possible.
Return valid JSON only using the required schema and allowed labels shown below.

UN-system repair rules:
- Do not introduce new high-risk needs (search_and_rescue, medical_support, evacuation,
  fire_response, flood_water_pumping) during repair. If a high-risk need was originally
  present but lacks evidence, move it to not_supported_needs.
- damage_severity must use the four-label image scale:
  none | moderate | destroyed | unknown. 'destroyed' may be downgraded
  to 'moderate' if evidence does not show >=50% collapse / total / near-total loss
  (UNOSAT 'Destroyed' threshold; rolls up to PDNA Volume A 'total damage').
- 'critical' priority may be downgraded to 'high' if no life-safety signal is cited
  AND no Sendai Target D critical-infrastructure (hospital, school) or critical-asset
  (bridge, power_station, water_network, airport, port) disruption is cited.

Required schema:
{{
  "damage_severity": {{"label": "...", "confidence": "...", "evidence": [], "uncertainty": []}},
  "affected_assets": [{{"label": "...", "status": "...", "confidence": "...", "evidence": "..."}}],
  "humanitarian_needs": [{{"label": "...", "confidence": "...", "evidence": "...", "need_type": "..."}}],
  "not_supported_needs": [{{"label": "...", "reason": "..."}}],
  "priority_risk": {{"label": "...", "confidence": "...", "rationale": [], "not_critical_reason": "...", "recommended_actions": [], "human_review_required": true}},
  "absence_checks": [],
  "uncertainties": []
}}"""

# ---------------------------------------------------------------------------
# Verifier prompt
# ---------------------------------------------------------------------------

VERIFIER_SYSTEM_PROMPT = """\
You are verifying a generated humanitarian disaster annotation against the original \
DisasterVL evidence packet, applying UN-system conservatism: UNOSAT / IWG-SEM analyst \
practice for image-based damage classification and PDNA Volume A (UNDG / EU / World \
Bank, 2013) evidence-based recovery planning.

Check whether each positive label is supported by the evidence. Treat VQA absence_check \
entries as authoritative negative evidence: any positive label they contradict is \
unsupported.

Specific verification thresholds:
- damage_severity 'destroyed' requires evidence of total / near-total loss (UNOSAT \
  'Destroyed' >=50% collapse threshold; rolls up to PDNA Volume A 'total damage').
- damage_severity 'moderate' covers any visible non-destroyed damage, including prior \
  minor/moderate/severe subclasses.
- priority_risk 'critical' requires evidence of life-safety risk OR damage to Sendai \
  Target D critical infrastructure (hospital, school) OR major disruption of a \
  critical asset (bridge, power_station, water_network, airport, port).
- High-risk needs (search_and_rescue, medical_support, evacuation, fire_response, \
  flood_water_pumping) require explicit life-safety or hazard evidence.

Do not add new labels. Only mark each label as:
- supported
- weakly_supported
- unsupported

Return valid JSON only. No markdown. No commentary."""

VERIFIER_USER_TEMPLATE = """\
Check each positive label in the generated annotation against the original evidence.

Return this exact JSON schema:
{{
  "overall_decision": "accept|revise|reject",
  "label_checks": [
    {{
      "field": "...",
      "label": "...",
      "decision": "supported|weakly_supported|unsupported",
      "reason": "..."
    }}
  ],
  "required_revisions": []
}}

ORIGINAL_EVIDENCE_PACKET:
{evidence_packet_json}

GENERATED_ANNOTATION:
{generated_annotation_json}"""


def build_annotation_messages(
    packet: dict, candidates: dict
) -> list[dict]:
    user = ANNOTATION_USER_TEMPLATE.format(
        evidence_packet_json=json.dumps(packet, ensure_ascii=False),
        candidate_labels_json=json.dumps(candidates, ensure_ascii=False),
    )
    return [
        {"role": "system", "content": ANNOTATION_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]


# ---------------------------------------------------------------------------
# API v2 annotation generation
# ---------------------------------------------------------------------------

API_V2_ANNOTATION_SYSTEM_PROMPT = """\
You are an expert humanitarian disaster annotation assistant.

You will receive outputs from the DisasterVL API, especially caption and
incident_reasoning. Your task is to convert those API outputs into the same
extra4 structured labels used by the DisasterVL extra annotation pipeline:

1. damage_severity
2. affected_assets
3. humanitarian_needs
4. priority_risk

Use only the provided DisasterVL API evidence. Do not invent facts that are not
supported by the API caption, incident reasoning, optional reasoning_vqa answers,
or extracted absence/uncertainty notes. Do not infer casualties, trapped people,
medical needs, evacuation, exact location, or cause unless explicitly supported.

Every positive label must cite a short piece of evidence copied or closely
paraphrased from the API output. Treat absence/uncertainty notes as negative or
weak evidence. Be conservative for high-stakes labels.

Return valid JSON only. No markdown fences. No commentary."""

API_V2_ANNOTATION_USER_TEMPLATE = """\
Create extra-task annotations from this DisasterVL API output.

The input evidence came from API calls such as:
- task=caption
- task=incident_reasoning
- optional task=reasoning_vqa

ALLOWED LABELS

damage_severity:
  none | moderate | destroyed | unknown
  - destroyed: total or near-total loss/collapse.
  - moderate: any visible non-destroyed damage, including prior minor, moderate,
    or severe subclasses.
  - none: no visible damage.
  - unknown: evidence is insufficient to assess.

affected_asset labels:
  residential_building, school, hospital, religious_building, public_building,
  sidewalk, commercial_building, market, agricultural_land, fuel_station, road,
  bridge, railway, airport, port, traffic_signal, power_line, power_station,
  water_network, telecom_infrastructure, forest, river, coastline, excavator,
  emergency_vehicle, rescue_worker, vehicle, unknown

asset_status:
  visible_nearby | undamaged_or_intact | minor_damage | moderate_damage |
  severely_damaged | destroyed | obstructed | partially_impacted | unknown

humanitarian_needs:
  temporary_housing_assessment, water_infrastructure_repair, debris_clearance,
  road_access_assessment, road_access_restoration, power_restoration,
  communications_restoration, food_water_sanitation, logistics_support,
  livelihood_support, agricultural_support, shelter, structural_safety_inspection,
  search_and_rescue, medical_support, evacuation, fire_response,
  flood_water_pumping, unknown

need_type:
  visible | inferred_from_visible_damage | requires_human_verification

priority_risk:
  low | medium | high | critical | unknown

RULES
- Use only the DISASTERVL_API_EVIDENCE_PACKET.
- Positive labels require evidence strings from the API output.
- Use "unknown" or low confidence when the API output is uncertain.
- For damage_severity, do not output "minor" or "severe"; map any visible
  non-destroyed damage to "moderate".
- High-risk needs require explicit evidence:
  search_and_rescue needs trapped/rescue evidence.
  medical_support needs injured/medical evidence.
  evacuation needs evacuation/displacement/unsafe-occupancy evidence.
  fire_response needs fire/flames/smoke/active fire evidence.
  flood_water_pumping needs visible flooding/standing water/submerged evidence.
- If the API output says there is no visible damage, no fire, no flooding, no
  injured people, or no trapped people, do not generate the contradicting need.
- priority_risk=critical requires explicit life-safety evidence, active severe
  hazard, or damaged critical infrastructure such as hospital, school, bridge,
  power_station, water_network, airport, or port.
- Preserve uncertainty from the API output.

Return this exact JSON schema:
{{
  "damage_severity": {{
    "label": "...",
    "confidence": "low|medium|high",
    "evidence": [],
    "uncertainty": []
  }},
  "affected_assets": [
    {{
      "label": "...",
      "status": "...",
      "confidence": "low|medium|high",
      "evidence": "..."
    }}
  ],
  "humanitarian_needs": [
    {{
      "label": "...",
      "confidence": "low|medium|high",
      "evidence": "...",
      "need_type": "visible|inferred_from_visible_damage|requires_human_verification"
    }}
  ],
  "not_supported_needs": [
    {{
      "label": "...",
      "reason": "..."
    }}
  ],
  "priority_risk": {{
    "label": "low|medium|high|critical|unknown",
    "confidence": "low|medium|high",
    "rationale": [],
    "not_critical_reason": "...",
    "recommended_actions": [],
    "human_review_required": true
  }},
  "absence_checks": [],
  "uncertainties": []
}}

DISASTERVL_API_EVIDENCE_PACKET:
{evidence_packet_json}

CANDIDATE_LABELS:
{candidate_labels_json}"""


def build_api_v2_annotation_messages(
    packet: dict, candidates: dict
) -> list[dict]:
    user = API_V2_ANNOTATION_USER_TEMPLATE.format(
        evidence_packet_json=json.dumps(packet, ensure_ascii=False),
        candidate_labels_json=json.dumps(candidates, ensure_ascii=False),
    )
    return [
        {"role": "system", "content": API_V2_ANNOTATION_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]


def build_repair_messages(errors: list[str], broken_json: str) -> list[dict]:
    user = REPAIR_USER_TEMPLATE.format(
        validation_errors="\n".join(f"- {e}" for e in errors),
        broken_json=broken_json,
    )
    return [
        {"role": "system", "content": REPAIR_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]


def build_verifier_messages(packet: dict, annotation: dict) -> list[dict]:
    user = VERIFIER_USER_TEMPLATE.format(
        evidence_packet_json=json.dumps(packet, indent=2, ensure_ascii=False),
        generated_annotation_json=json.dumps(annotation, indent=2, ensure_ascii=False),
    )
    return [
        {"role": "system", "content": VERIFIER_SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]
