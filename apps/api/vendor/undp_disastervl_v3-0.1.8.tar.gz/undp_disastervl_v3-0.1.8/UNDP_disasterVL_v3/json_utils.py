"""JSON extraction helpers for LLM outputs."""

from __future__ import annotations

import json
import re


def extract_json(raw: str) -> dict | None:
    cleaned = re.sub(r"```(?:json)?", "", raw or "").strip().rstrip("`").strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    match = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            pass
    return None

