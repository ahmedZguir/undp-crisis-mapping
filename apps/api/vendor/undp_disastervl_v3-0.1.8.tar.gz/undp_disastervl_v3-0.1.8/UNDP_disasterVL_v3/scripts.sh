#!/usr/bin/env bash
set -eo pipefail

# One-image smoke test for the library version.

source ~/.bashrc
conda activate qwen35_h200
set -u

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export UNDP_V3_BASE_MODEL="${UNDP_V3_BASE_MODEL:-Qwen/Qwen3.5-9B}"
export UNDP_V3_ADAPTER_PATH="${UNDP_V3_ADAPTER_PATH:-/home/local/QCRI/adiba/CR1M_VLM/experiments/Q35VL_9B_MCQ_final_XLData/CR1M_data/checkpoints/best_checkpoint}"
export UNDP_V3_TENSOR_PARALLEL_SIZE="${UNDP_V3_TENSOR_PARALLEL_SIZE:-1}"
export UNDP_V3_DEFAULT_MAX_TOKENS="${UNDP_V3_DEFAULT_MAX_TOKENS:-256}"
export UNDP_V3_EXTRA4_MAX_TOKENS="${UNDP_V3_EXTRA4_MAX_TOKENS:-1024}"

IMAGE="${1:-/home/local/QCRI/adiba/CR1M_VLM/disastervl_API/test_img.jpg}"
OUT="${2:-/tmp/test_img_extra4_v3.json}"
TASK="${TASK:-all}"

python -m UNDP_disasterVL_v3.run_sample "$IMAGE" --task "$TASK" --output "$OUT"
echo "Wrote $OUT"
