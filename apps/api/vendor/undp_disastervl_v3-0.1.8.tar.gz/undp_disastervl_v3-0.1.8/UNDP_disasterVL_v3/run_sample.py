#!/usr/bin/env python3
"""Run one image through the vLLM library pipeline."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .pipeline import (
    DisasterVLRemoteVLLM,
    DisasterVLRemoteVLLMConfig,
    DisasterVLVLLM,
    DisasterVLVLLMConfig,
)

TASK_CHOICES = ("caption", "incident_reasoning", "reasoning_vqa", "all")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("image", type=Path)
    p.add_argument("--output", type=Path)
    p.add_argument("--image_id", default="")
    p.add_argument("--adapter_path", default="")
    p.add_argument("--base_model", default="")
    p.add_argument("--backend", choices=["local", "remote"], default="local")
    p.add_argument(
        "--task",
        choices=TASK_CHOICES,
        default="all",
        help="Which task to run. 'all' runs caption, incident reasoning, and extra4.",
    )
    p.add_argument(
        "--tasks",
        nargs="+",
        choices=TASK_CHOICES,
        default=None,
        help=(
            "Run multiple selected tasks without extra4. Example: "
            "--tasks caption incident_reasoning. Do not combine 'all' with other tasks."
        ),
    )
    p.add_argument(
        "--reasoning_vqa_query",
        action="append",
        default=[],
        help="Reasoning VQA query. Can be passed multiple times.",
    )
    p.add_argument("--api_base", default="")
    p.add_argument("--disaster_model", default="")
    p.add_argument("--tensor_parallel_size", type=int, default=None)
    p.add_argument("--extra4_max_tokens", type=int, default=None)
    p.add_argument("--return_raw_llm_output", action="store_true")
    return p


def main() -> None:
    parser = build_parser()
    args, unknown = parser.parse_known_args()
    if unknown:
        if str(args.image) in TASK_CHOICES:
            parser.error(
                "--task accepts only one value. Use '--task all' for the full pipeline, "
                "or '--tasks caption incident_reasoning' for multiple selected outputs."
            )
        parser.error(f"unrecognized arguments: {' '.join(unknown)}")

    if args.tasks and "all" in args.tasks and len(args.tasks) > 1:
        parser.error("--tasks cannot combine 'all' with other tasks.")

    if args.backend == "remote":
        config = DisasterVLRemoteVLLMConfig.from_env()
        overrides = {}
        if args.api_base:
            overrides["api_base"] = args.api_base.rstrip("/")
        if args.base_model:
            overrides["base_model"] = args.base_model
        if args.disaster_model:
            overrides["disaster_model"] = args.disaster_model
        if args.extra4_max_tokens is not None:
            overrides["extra4_max_tokens"] = args.extra4_max_tokens
        if overrides:
            from dataclasses import replace

            config = replace(config, **overrides)
        pipeline = DisasterVLRemoteVLLM(config)
    else:
        config = DisasterVLVLLMConfig.from_env()
        overrides = {}
        if args.adapter_path:
            overrides["adapter_path"] = args.adapter_path
        if args.base_model:
            overrides["base_model"] = args.base_model
        if args.tensor_parallel_size is not None:
            overrides["tensor_parallel_size"] = args.tensor_parallel_size
        if args.extra4_max_tokens is not None:
            overrides["extra4_max_tokens"] = args.extra4_max_tokens
        if overrides:
            from dataclasses import replace

            config = replace(config, **overrides)
        pipeline = DisasterVLVLLM(config)
    image_id = args.image_id or args.image.stem
    if args.tasks:
        result = {
            "image_id": image_id,
            "image_path": str(args.image),
            "tasks": args.tasks,
            "results": {
                task: pipeline.analyze(
                    args.image,
                    task=task,
                    image_id=image_id,
                    reasoning_vqa_queries=args.reasoning_vqa_query,
                    return_raw_llm_output=args.return_raw_llm_output,
                )
                for task in args.tasks
            },
        }
    else:
        result = pipeline.analyze(
            args.image,
            task=args.task,
            image_id=image_id,
            reasoning_vqa_queries=args.reasoning_vqa_query,
            return_raw_llm_output=args.return_raw_llm_output,
        )

    text = json.dumps(result, indent=2, ensure_ascii=False)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    else:
        print(text)


if __name__ == "__main__":
    main()
