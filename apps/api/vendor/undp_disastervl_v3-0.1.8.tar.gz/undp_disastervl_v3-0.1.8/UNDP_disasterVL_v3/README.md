# UNDP DisasterVL V3

Python package for running the DisasterVL extra4 annotation pipeline with vLLM.

It supports two modes:

- **Local in-process vLLM**: `DisasterVLVLLM` loads vLLM directly inside your Python process.
- **Remote vLLM server client**: `DisasterVLRemoteVLLM` calls an already running OpenAI-compatible vLLM server.

The pipeline runs:

```text
image
-> caption with DisasterVL LoRA
-> incident_reasoning with DisasterVL LoRA
-> optional reasoning_vqa with DisasterVL LoRA
-> extra4 annotation with base model
```

`damage_severity` uses four labels: `none`, `moderate`, `destroyed`, `unknown`.

## Install

Lightweight install for remote vLLM server usage:

```bash
pip install .
```

Full install for local in-process vLLM usage:

```bash
pip install ".[vllm]"
```

Build a wheel:

```bash
python -m pip install build
python -m build
```

Install the built wheel:

```bash
pip install dist/undp_disastervl_v3-0.1.0-py3-none-any.whl
```

## Remote vLLM Server Mode

Start the external vLLM server:

```bash
export CUDA_VISIBLE_DEVICES=0
export UNDP_V3_BASE_MODEL=Qwen/Qwen3.5-9B
export UNDP_V3_ADAPTER_NAME=disastervl
export UNDP_V3_ADAPTER_PATH=/path/to/disastervl_adapter_checkpoint

bash UNDP_disasterVL_v3/start_vllm_server.sh
```

Use the Python client:

```python
from UNDP_disasterVL_v3 import DisasterVLRemoteVLLM

pipeline = DisasterVLRemoteVLLM()
result = pipeline.analyze("/path/to/image.jpg", task="all")
print(result["extra_task_annotations"])
```

Routing behavior:

- `task="caption"` uses the DisasterVL LoRA model served as `disastervl`.
- `task="incident_reasoning"` uses the DisasterVL LoRA model served as `disastervl`.
- `task="reasoning_vqa"` uses the DisasterVL LoRA model served as `disastervl` and requires at least one query.
- `task="all"` runs the full pipeline: DisasterVL LoRA for caption and incident reasoning, then the base Qwen model for extra4 annotation.

Run only selected outputs:

```python
caption = pipeline.analyze("/path/to/image.jpg", task="caption")
incident = pipeline.analyze("/path/to/image.jpg", task="incident_reasoning")
vqa = pipeline.analyze(
    "/path/to/image.jpg",
    task="reasoning_vqa",
    reasoning_vqa_queries=["Is there visible flooding?"],
)
full = pipeline.analyze("/path/to/image.jpg", task="all")
```

## Local In-Process vLLM Mode

```python
from UNDP_disasterVL_v3 import DisasterVLVLLM

pipeline = DisasterVLVLLM()
result = pipeline.analyze("/path/to/image.jpg", task="all")
print(result["extra_task_annotations"])
```

Instantiate the pipeline once and reuse it. Creating a new pipeline object reloads the vLLM engine.

## CLI

Local mode:

```bash
undp-disastervl-v3-sample /path/to/image.jpg --output /tmp/output.json
```

Remote mode:

```bash
undp-disastervl-v3-sample \
  --backend remote \
  --tasks caption  \
  --api_base http://127.0.0.1:8000/v1 \
  --base_model Qwen/Qwen3.5-9B \
  --disaster_model disastervl \
  /home/local/QCRI/adiba/CR1M_VLM/disastervl_API/test_img.jpg \
  --output UNDP_disasterVL_v3/outputs/output.json
```

Only caption:

```bash
undp-disastervl-v3-sample --backend remote --tasks caption /home/local/QCRI/adiba/CR1M_VLM/disastervl_API/test_img.jpg
```

Caption and incident reasoning without extra4:

```bash
undp-disastervl-v3-sample \
  --backend remote \
  --tasks caption incident_reasoning \
  --api_base http://127.0.0.1:8000/v1 \
  --base_model Qwen/Qwen3.5-9B \
  --disaster_model disastervl \
  /home/local/QCRI/adiba/CR1M_VLM/disastervl_API/test_img.jpg \
  --output UNDP_disasterVL_v3/outputs/output.json
```

## Speed Benchmark

Run each task 3 times on one image:

```bash
python -m UNDP_disasterVL_v3.benchmark \
  --backend remote \
  --api_base http://127.0.0.1:8000/v1 \
  --base_model Qwen/Qwen3.5-9B \
  --disaster_model disastervl \
  --runs 3 \
  --tasks all \
  /home/local/QCRI/adiba/CR1M_VLM/disastervl_API/test_img.jpg \
  --output UNDP_disasterVL_v3/outputs/undp_v3_speed.json
```

After package install, the console command is:

```bash
undp-disastervl-v3-benchmark \
  --backend remote \
  --runs 3 \
  --tasks caption incident_reasoning all \
  /path/to/image.jpg
```

## Model Files

Model weights are not included in this package. Set the adapter and model paths with environment variables:

```bash
export UNDP_V3_BASE_MODEL=Qwen/Qwen3.5-9B
export UNDP_V3_ADAPTER_PATH=/path/to/disastervl_adapter_checkpoint
```
