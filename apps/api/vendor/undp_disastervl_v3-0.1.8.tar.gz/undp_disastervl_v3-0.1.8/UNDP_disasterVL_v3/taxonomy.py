"""Controlled taxonomies for the four extra-task annotation tasks."""

DAMAGE_SEVERITY_LABELS = {
    "none", "moderate", "destroyed", "unknown"
}

HUMANITARIAN_NEEDS_LABELS = {
    "search_and_rescue",
    "medical_support",
    "evacuation",
    "shelter",
    "temporary_housing_assessment",
    "debris_clearance",
    "structural_safety_inspection",
    "road_access_assessment",
    "road_access_restoration",
    "fire_response",
    "flood_water_pumping",
    "food_water_sanitation",
    "power_restoration",
    "communications_restoration",
    "logistics_support",
    "livelihood_support",
    "agricultural_support",
    "water_infrastructure_repair",
    "unknown",
}

# Needs that must not be assigned without direct visible evidence
HIGH_RISK_NEEDS = {"search_and_rescue", "medical_support", "evacuation"}

AFFECTED_ASSET_LABELS = {
    "residential_building",
    "commercial_building",
    "school",
    "hospital",
    "public_building",
    "religious_building",
    "road",
    "bridge",
    "sidewalk",
    "traffic_signal",
    "railway",
    "airport",
    "port",
    "vehicle",
    "power_line",
    "power_station",
    "water_network",
    "telecom_infrastructure",
    "fuel_station",
    "market",
    "agricultural_land",
    "forest",
    "river",
    "coastline",
    "excavator",
    "emergency_vehicle",
    "rescue_worker",
    "unknown",
}

ASSET_STATUS_LABELS = {
    "visible_nearby",
    "undamaged_or_intact",
    "minor_damage",
    "moderate_damage",
    "severely_damaged",
    "destroyed",
    "obstructed",
    "partially_impacted",
    "unknown",
}

PRIORITY_LABELS = {"low", "medium", "high", "critical", "unknown"}

CONFIDENCE_LABELS = {"low", "medium", "high"}

NEED_TYPE_LABELS = {
    "visible",
    "inferred_from_visible_damage",
    "requires_human_verification",
}

VALIDATION_STATUS_LABELS = {"passed", "flagged", "rejected"}


def validate_label(value: str, allowed: set, field_name: str) -> tuple[bool, str]:
    if value not in allowed:
        return False, f"{field_name}='{value}' not in allowed set: {sorted(allowed)}"
    return True, ""
