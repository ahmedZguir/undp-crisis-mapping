#!/usr/bin/env python3
"""Benchmark V3 task latency on one image."""

from __future__ import annotations

import argparse
import json
import statistics
import time
from dataclasses import replace
from pathlib import Path
from typing import Any

from .pipeline import (
    DisasterVLRemoteVLLM,
    DisasterVLRemoteVLLMConfig,
    DisasterVLVLLM,
    DisasterVLVLLMConfig,
)


TASKS = ("caption", "incident_reasoning", "reasoning_vqa", "all")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("image", type=Path, nargs="?")
    p.add_argument("--backend", choices=["local", "remote"], default="remote")
    p.add_argument("--runs", type=int, default=3)
    p.add_argument(
        "--tasks",
        nargs="*",
        default=list(TASKS),
        help="Tasks to benchmark: caption incident_reasoning reasoning_vqa all",
    )
    p.add_argument("--output", type=Path)
    p.add_argument("--api_base", default="")
    p.add_argument("--base_model", default="")
    p.add_argument("--disaster_model", default="")
    p.add_argument("--adapter_path", default="")
    p.add_argument("--tensor_parallel_size", type=int)
    p.add_argument("--extra4_max_tokens", type=int)
    p.add_argument(
        "--return_raw_llm_output",
        action="store_true",
        help="Include raw extra4 LLM output in the benchmark JSON for rejected/flagged debugging.",
    )
    p.add_argument(
        "--reasoning_vqa_query",
        default="Are any roads blocked, damaged, or obstructed?",
    )
    p.add_argument("--warmup", action="store_true")
    return p


def main() -> None:
    args = build_parser().parse_args()
    _normalize_args(args)
    pipeline = _build_pipeline(args)
    image_id = args.image.stem

    if args.warmup:
        print("Warmup: caption", flush=True)
        pipeline.analyze(args.image, task="caption", image_id=image_id)

    results: list[dict[str, Any]] = []
    for task in args.tasks:
        print(f"\nTask: {task}", flush=True)
        durations = []
        for run_idx in range(1, args.runs + 1):
            t0 = time.perf_counter()
            output = pipeline.analyze(
                args.image,
                task=task,
                image_id=image_id,
                reasoning_vqa_queries=[args.reasoning_vqa_query],
                return_evidence_packet=False,
                return_disastervl_outputs=False,
                return_raw_llm_output=args.return_raw_llm_output,
            )
            elapsed = time.perf_counter() - t0
            durations.append(elapsed)
            metadata = output.get("annotation_metadata") or {} if isinstance(output, dict) else {}
            result = {
                "task": task,
                "run": run_idx,
                "seconds": elapsed,
                "validation_status": metadata.get("validation_status"),
                "validation_errors": metadata.get("validation_errors") or [],
                "repaired": metadata.get("repaired"),
            }
            if args.return_raw_llm_output and "raw_llm_output" in metadata:
                result["raw_llm_output"] = metadata["raw_llm_output"]
            results.append(result)
            print(
                f"  run {run_idx}/{args.runs}: {elapsed:.3f}s"
                + (
                    f" status={result['validation_status']}"
                    if result["validation_status"]
                    else ""
                ),
                flush=True,
            )
            if result["validation_errors"]:
                print(
                    "    validation_errors="
                    + "; ".join(str(err) for err in result["validation_errors"][:3]),
                    flush=True,
                )

        summary = _summary(durations)
        print(
            f"  avg={summary['avg_seconds']:.3f}s "
            f"median={summary['median_seconds']:.3f}s "
            f"min={summary['min_seconds']:.3f}s "
            f"max={summary['max_seconds']:.3f}s",
            flush=True,
        )

    report = {
        "image": str(args.image),
        "backend": args.backend,
        "runs_per_task": args.runs,
        "tasks": list(args.tasks),
        "results": results,
        "summary": {
            task: _summary([r["seconds"] for r in results if r["task"] == task])
            for task in args.tasks
        },
    }

    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        print(f"\nWrote {args.output}", flush=True)


def _normalize_args(args) -> None:
    """Handle `--tasks caption ... all image.jpg`.

    argparse cannot know where a variable-length option should stop when the
    positional image comes after it. Treat the first non-task token in --tasks
    as the image path when the image positional was omitted.
    """
    normalized_tasks = []
    extra_tokens = []
    for token in args.tasks or []:
        if token in TASKS and not extra_tokens:
            normalized_tasks.append(token)
        else:
            extra_tokens.append(token)

    if extra_tokens and args.image is None:
        args.image = Path(extra_tokens[0])
        extra_tokens = extra_tokens[1:]

    if extra_tokens:
        raise SystemExit(f"Unexpected argument(s) after --tasks: {' '.join(extra_tokens)}")

    if not normalized_tasks:
        normalized_tasks = list(TASKS)

    invalid = [task for task in normalized_tasks if task not in TASKS]
    if invalid:
        raise SystemExit(
            f"Invalid task(s): {', '.join(invalid)}. Choose from: {', '.join(TASKS)}"
        )

    if args.image is None:
        raise SystemExit("image is required")

    args.tasks = normalized_tasks


def _build_pipeline(args):
    if args.backend == "remote":
        config = DisasterVLRemoteVLLMConfig.from_env()
        overrides = {}
        if args.api_base:
            overrides["api_base"] = args.api_base.rstrip("/")
        if args.base_model:
            overrides["base_model"] = args.base_model
        if args.disaster_model:
            overrides["disaster_model"] = args.disaster_model
        if args.extra4_max_tokens is not None:
            overrides["extra4_max_tokens"] = args.extra4_max_tokens
        return DisasterVLRemoteVLLM(replace(config, **overrides) if overrides else config)

    config = DisasterVLVLLMConfig.from_env()
    overrides = {}
    if args.base_model:
        overrides["base_model"] = args.base_model
    if args.adapter_path:
        overrides["adapter_path"] = args.adapter_path
    if args.tensor_parallel_size is not None:
        overrides["tensor_parallel_size"] = args.tensor_parallel_size
    if args.extra4_max_tokens is not None:
        overrides["extra4_max_tokens"] = args.extra4_max_tokens
    return DisasterVLVLLM(replace(config, **overrides) if overrides else config)


def _summary(values: list[float]) -> dict[str, float]:
    if not values:
        return {
            "avg_seconds": 0.0,
            "median_seconds": 0.0,
            "min_seconds": 0.0,
            "max_seconds": 0.0,
        }
    return {
        "avg_seconds": statistics.mean(values),
        "median_seconds": statistics.median(values),
        "min_seconds": min(values),
        "max_seconds": max(values),
    }


if __name__ == "__main__":
    main()
