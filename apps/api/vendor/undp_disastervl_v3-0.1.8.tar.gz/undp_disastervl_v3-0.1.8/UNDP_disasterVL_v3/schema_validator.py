"""Schema validation for extra-task annotation outputs."""

from __future__ import annotations

from .taxonomy import (
    DAMAGE_SEVERITY_LABELS,
    HUMANITARIAN_NEEDS_LABELS,
    AFFECTED_ASSET_LABELS,
    ASSET_STATUS_LABELS,
    PRIORITY_LABELS,
    CONFIDENCE_LABELS,
    NEED_TYPE_LABELS,
)

REQUIRED_TOP_KEYS = {
    "damage_severity",
    "affected_assets",
    "humanitarian_needs",
    "not_supported_needs",
    "priority_risk",
    "absence_checks",
    "uncertainties",
}


def validate(annotation: dict) -> list[str]:
    """Validate annotation against the schema. Returns list of error strings."""
    errors: list[str] = []

    if not isinstance(annotation, dict):
        return ["annotation is not a dict"]

    missing = REQUIRED_TOP_KEYS - annotation.keys()
    if missing:
        errors.append(f"missing required keys: {sorted(missing)}")

    # damage_severity
    ds = annotation.get("damage_severity") or {}
    if not isinstance(ds, dict):
        errors.append("damage_severity must be a dict")
    else:
        label = ds.get("label", "")
        if label not in DAMAGE_SEVERITY_LABELS:
            errors.append(f"damage_severity.label='{label}' invalid")
        if ds.get("confidence", "") not in CONFIDENCE_LABELS:
            errors.append(f"damage_severity.confidence='{ds.get('confidence')}' invalid")
        if label not in ("none", "unknown") and not ds.get("evidence"):
            errors.append("damage_severity.evidence must be non-empty for positive labels")

    # affected_assets
    assets = annotation.get("affected_assets") or []
    if not isinstance(assets, list):
        errors.append("affected_assets must be a list")
    else:
        for i, asset in enumerate(assets):
            if not isinstance(asset, dict):
                errors.append(f"affected_assets[{i}] must be a dict")
                continue
            if asset.get("label", "") not in AFFECTED_ASSET_LABELS:
                errors.append(f"affected_assets[{i}].label='{asset.get('label')}' invalid")
            if asset.get("status", "") not in ASSET_STATUS_LABELS:
                errors.append(f"affected_assets[{i}].status='{asset.get('status')}' invalid")
            if asset.get("confidence", "") not in CONFIDENCE_LABELS:
                errors.append(f"affected_assets[{i}].confidence invalid")
            if not asset.get("evidence"):
                errors.append(f"affected_assets[{i}].evidence must be non-empty")

    # humanitarian_needs
    needs = annotation.get("humanitarian_needs") or []
    if not isinstance(needs, list):
        errors.append("humanitarian_needs must be a list")
    else:
        for i, need in enumerate(needs):
            if not isinstance(need, dict):
                errors.append(f"humanitarian_needs[{i}] must be a dict")
                continue
            if need.get("label", "") not in HUMANITARIAN_NEEDS_LABELS:
                errors.append(f"humanitarian_needs[{i}].label='{need.get('label')}' invalid")
            if need.get("confidence", "") not in CONFIDENCE_LABELS:
                errors.append(f"humanitarian_needs[{i}].confidence invalid")
            if not need.get("evidence"):
                errors.append(f"humanitarian_needs[{i}].evidence must be non-empty")
            if need.get("need_type", "") not in NEED_TYPE_LABELS:
                errors.append(f"humanitarian_needs[{i}].need_type='{need.get('need_type')}' invalid")

    # not_supported_needs
    unsupported = annotation.get("not_supported_needs") or []
    if not isinstance(unsupported, list):
        errors.append("not_supported_needs must be a list")
    else:
        for i, item in enumerate(unsupported):
            if not isinstance(item, dict):
                errors.append(f"not_supported_needs[{i}] must be a dict")
                continue
            if not item.get("label"):
                errors.append(f"not_supported_needs[{i}].label missing")
            if not item.get("reason"):
                errors.append(f"not_supported_needs[{i}].reason missing")

    # priority_risk
    pr = annotation.get("priority_risk") or {}
    if not isinstance(pr, dict):
        errors.append("priority_risk must be a dict")
    else:
        if pr.get("label", "") not in PRIORITY_LABELS:
            errors.append(f"priority_risk.label='{pr.get('label')}' invalid")
        if pr.get("confidence", "") not in CONFIDENCE_LABELS:
            errors.append(f"priority_risk.confidence invalid")
        if not pr.get("rationale"):
            errors.append("priority_risk.rationale must be non-empty")

    return errors


def is_valid(annotation: dict) -> bool:
    return len(validate(annotation)) == 0
